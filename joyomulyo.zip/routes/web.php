<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => ['auth']], function () {
    Route::get('/admin', 'HomeController@index')->name('admin.index');
    Route::get('/home', 'HomeController@index')->name('admin.index');
    Route::get('/panen', 'PanenController@index')->name('panen.index');
    Route::get('/harga', 'PanenController@harga')->name('panen.harga');
    Route::get('/panen/create', 'PanenController@create')->name('panen.create');
    Route::post('/panen/create', 'PanenController@store')->name('panen.store');
    Route::get('/panen/jual', 'PanenController@createPenjualan')->name('panen.cjual');
    Route::post('/panen/jual', 'PanenController@storePenjualan')->name('panen.sjual');
    Route::resource('petani', PetaniController::class);
});

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
