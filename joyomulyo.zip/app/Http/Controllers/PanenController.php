<?php

namespace App\Http\Controllers;

use App\Harga;
use App\Panen;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PanenController extends Controller
{
    public function index()
    {
        $dataPanen = Panen::join('users', 'id_petani', '=', 'users.id')->get(['panens.*', 'users.name', 'users.dusun']);
        $dataPanen2 = Panen::where('id_petani', '=', Auth::user()->id)->get();
        return view('panen.index', compact('dataPanen', 'dataPanen2'));
    }

    public function create()
    {
        $dataPetani = User::where('role', 'Petani')->get();
        return view('panen.add', compact('dataPetani'));
    }

    public function store(Request $request)
    {
        Panen::create([
            'tanggal' => Carbon::now()->setTimezone('Asia/Jakarta'),
            'id_petani' => $request->id_petani,
            'berat' => $request->berat,
            'hasil_penjualan' => $request->hasil_penjualan
        ]);
        return redirect()->route('panen.index')->with('success', 'Data panen berhasil ditambah');
    }

    public function createPenjualan()
    {
        return view('panen.jual');
    }

    public function detailPenjualan($id)
    {
        $detailPanen = Panen::where('id', '=', $id)->get();
        return view('panen.detail', compact('detailPanen'));
    }

    public function storePenjualan(Request $request)
    {
        $tanggal = Carbon::now()->setTimezone('Asia/Jakarta')->format('Y-m-d');
        $dataPanen = Panen::where('tanggal', '=', $tanggal)->get();
        foreach ($dataPanen as $panen) {
            $panen->hasil_penjualan = $request->harga * $panen->berat;
            $panen->update();
        }
        Harga::create([
            'tanggal' => $tanggal,
            'harga' => $request->harga
        ]);
        return redirect()->route('panen.index')->with('success', 'Data penjualan berhasil ditambah');
    }

    public function harga()
    {
        $dataHarga = Harga::all();
        return view('panen.harga', compact('dataHarga'));
    }
}
