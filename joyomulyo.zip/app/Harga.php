<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Harga extends Model
{
    protected $fillable = ['tanggal', 'harga'];
}
