@extends('backend.app')

@section('content')
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row page-titles">
        <div class="col-md-5 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Data Panen</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ URL('/admin') }}">Home</a></li>
                <li class="breadcrumb-item active">Data Panen</li>
            </ol>
        </div>
    </div>
    <div class="row">
        <!-- Column -->
        <div class="card col-md-12">
            <div class="card-body">
                @if (session('success'))
                <div class="card-body">
                    <div class="alert alert-success alert-dismissible show fade">
                        <div class="alert-body">
                            <button class="close" data-dismiss="alert">
                                <span>&times;</span>
                            </button>
                            {{ session('success') }}
                        </div>
                    </div>
                </div>
                @elseif(session('warning'))
                <div class="card-body">
                    <div class="alert alert-warning alert-dismissible show fade">
                        <div class="alert-body">
                            <button class="close" data-dismiss="alert">
                                <span>&times;</span>
                            </button>
                            {{ session('warning') }}
                        </div>
                    </div>
                </div>
                @endif
                <h4 class="card-title">Data Panen</h4>
                @if (Auth::user()->role == 'Pengepul')
                <a href="{{ URL('/panen/create') }}" class="btn btn-primary">Tambah Data Panen</a>
                {{-- @elseif (Auth::user()->role == 'Pengepul' || Auth::user()->role == 'Kades') --}}
                <div class="row">
                    <div class="table-responsive m-t-20">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 5%">No.</th>
                                    <th style="width: 25%">Tanggal</th>
                                    <th style="width: 20%">Nama Petani</th>
                                    <th style="width: 15%">Dusun</th>
                                    <th style="width: 15%">Berat</th>
                                    @if (Auth::user()->role == 'Pengepul')
                                    <th style="width: 20%">Penjualan</th>
                                    @elseif (Auth::user()->role == 'Kades')
                                    <th style="width: 20%">Aksi</th>
                                    @endif
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($dataPanen as $no => $panen)
                                <tr>
                                    <td>{{ $no+1 }}</td>
                                    <td>{{ Carbon\Carbon::parse($panen->tanggal)->translatedFormat("l, d F Y") }}</td>
                                    <td>{{ $panen->name }}</td>
                                    <td>{{ $panen->dusun }}</td>
                                    <td>{{ $panen->berat }} Kg</td>
                                    @if ($panen->hasil_penjualan == 0 && Auth::user()->role == 'Pengepul')
                                    <td><a href="{{ URL('/panen/jual') }}" class="btn btn-warning">Masukkan Harga</a></td>
                                    @elseif ($panen->hasil_penjualan != 0 && Auth::user()->role == 'Pengepul')
                                    <td>Rp {{ number_format($panen->hasil_penjualan,2,',','.') }}</td>
                                    @elseif (Auth::user()->role == 'Kades')
                                    <td><a href="" class="btn btn-success">Detail</a></td>
                                    @endif
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                @else
                <div class="row">
                    <div class="table-responsive m-t-20">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 5%">No.</th>
                                    <th style="width: 45%">Tanggal</th>
                                    <th style="width: 30%">Berat</th>
                                    <th style="width: 20%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($dataPanen2 as $no => $panen)
                                <tr>
                                    <td>{{ $no+1 }}</td>
                                    <td>{{ Carbon\Carbon::parse($panen->tanggal)->translatedFormat("l, d F Y") }}</td>
                                    <td>{{ $panen->berat }} Kg</td>
                                    <td><a href="" class="btn btn-success">Detail</a></td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                @endif
                {{-- <div class="row">
                    <div class="table-responsive m-t-20">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 10%">No.</th>
                                    <th style="width: 30%">Tanggal</th>
                                    <th style="width: 30%">Jumlah Tiket</th>
                                    <th style="width: 30%">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($pengambilanLoket as $no => $pengambilan)
                                <tr>
                                    <td>{{ $no+1 }}</td>
                                    <td>{{ Carbon\Carbon::parse($pengambilan->tanggal)->translatedFormat("l, d F Y") }}</td>
                                    <td>@tiket($pengambilan->jumlah) Tiket</td>
                                    @if ($pengambilan->status == "Menunggu Verifikasi")
                                    <td><a href="#" class="btn btn-danger">Menunggu Verifikasi</a></td>
                                    @elseif ($pengambilan->status == "Sudah Verifikasi")
                                    <td><a href="#" class="btn btn-success">Sudah Verifikasi</a></td>
                                    @else
                                    <td><a href="#" class="btn btn-primary">Sudah Realisasi</a></td>
                                    @endif
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="input-daterange input-group" id="date-range-id">
                                <?php $tgl = Carbon\Carbon::now()->setTimezone('Asia/Jakarta')->format('Y-m-d'); ?>
                                <input type="hidden" class="form-control" name="tglAwal" id="tglAwal" placeholder="Tanggal Awal" value={{ $tgl }}>
                            </div>
                        </div>
                    </div>
                </div>
                --}}
            </div>
        </div>
    </div>
</div>
@endsection