<!-- Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- User profile -->
        <div class="user-profile" style="background: url(/assets/images/background/user-info.jpg) no-repeat;">
            <!-- User profile image -->
            
            <!-- User profile text-->
            <div class="profile-text"> <a href="#" class="dropdown-toggle link u-dropdown" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"><?php echo e(Auth::user()->name); ?><span class="caret"></span></a>
                <div class="dropdown-menu animated flipInY">
                    
                    <div class="dropdown-divider"></div> 
                    
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" 
                        onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();"><i class="fa fa-power-off"></i>
                            <?php echo e(__('Logout')); ?>

                    </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    
                </div>
            </div>
        </div>
        <!-- End User profile text-->
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="nav-small-cap">FITUR</li>
                <li>
                    <a href="<?php echo e(URL('/admin')); ?>" aria-expanded="false"><i class="fa fa-home"></i><span class="hide-menu">Dashboard</span></a>
                </li>
                <?php if(Auth::user()->role == 'Pengepul'): ?>
                <li>
                    <a href="<?php echo e(URL('/panen')); ?>" aria-expanded="false"><i class="fa fa-bar-chart-o"></i><span class="hide-menu">Data Panen</span></a>
                </li>
                <li>
                    <a href="<?php echo e(URL('/petani')); ?>" aria-expanded="false"><i class="fa fa-user"></i><span class="hide-menu">Data Petani</span></a>
                </li>
                <li>
                    <a href="<?php echo e(URL('/harga')); ?>" aria-expanded="false"><i class="fa fa-dollar"></i><span class="hide-menu">Data Harga</span></a>
                </li>
                <?php else: ?>
                <li>
                    <a href="<?php echo e(URL('/panen')); ?>" aria-expanded="false"><i class="fa fa-bar-chart-o"></i><span class="hide-menu">Data Panen</span></a>
                </li>
                <?php endif; ?>
                <?php if(Auth::user()->role == 'admin'): ?>
                
                <?php endif; ?>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
    <!-- Bottom points-->
    <div class="sidebar-footer">
        <a href="<?php echo e(route('logout')); ?>" class="link" data-toggle="tooltip" title="Logout" 
            onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i class="mdi mdi-power"></i>
        </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
    </div>
    <!-- End Bottom points-->
</aside>
<!-- ============================================================== -->
<!-- End Left Sidebar - style you can find in sidebar.scss  --><?php /**PATH D:\Coolyeah\laragon\www\joyomulyo\resources\views/backend/sidebar.blade.php ENDPATH**/ ?>