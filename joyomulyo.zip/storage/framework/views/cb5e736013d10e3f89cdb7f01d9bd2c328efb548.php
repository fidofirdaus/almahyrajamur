<!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo e(URL('/')); ?>/assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo e(URL('/')); ?>/assets/plugins/bootstrap/js/popper.min.js"></script>
    <script src="<?php echo e(URL('/')); ?>/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?php echo e(URL('/')); ?>/assets/js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="<?php echo e(URL('/')); ?>/assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?php echo e(URL('/')); ?>/assets/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="<?php echo e(URL('/')); ?>/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="<?php echo e(URL('/')); ?>/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo e(URL('/')); ?>/assets/js/custom.min.js"></script>
    <!-- ============================================================== -->
    
    <?php echo $__env->yieldPushContent('custom-js'); ?>
    <!-- ============================================================== -->
    <!-- Style switcher -->
    <!-- ============================================================== -->
    <script src="<?php echo e(URL('/')); ?>/assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
    
    <?php echo $__env->yieldPushContent('after-js'); ?><?php /**PATH D:\Coolyeah\laragon\www\joyomulyo\resources\views/backend/script.blade.php ENDPATH**/ ?>