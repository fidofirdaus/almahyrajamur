

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles">
        <div class="col-md-5 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0"><?php echo e(Auth::user()->role); ?> Dashboard</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(URL('/')); ?>">Home</a></li>
                <li class="breadcrumb-item active"><?php echo e(Auth::user()->role); ?> Dashboard</li>
            </ol>
        </div>
    </div>
    <div class="row">
        <div class="card-body">
            <div class="alert alert-success alert-dismissible show fade">
                <div class="alert-body">
                    <?php if(Auth::user()->role == 'Kades'): ?>
                    Halo, Bapak Kepala Desa !
                    <?php else: ?>
                    Halo, <?php echo e(Auth::user()->name); ?> !
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php if(Auth::user()->role == 'admin'): ?>
    
    <?php elseif(Auth::user()->id == 2 or Auth::user()->id == 3): ?>
    
    <?php else: ?>
    
    <?php endif; ?>
    <!-- Row -->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coolyeah\laragon\www\joyomulyo\resources\views/admin/index.blade.php ENDPATH**/ ?>