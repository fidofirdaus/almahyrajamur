

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row page-titles">
        <div class="col-md-5 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Data Panen</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(URL('/admin')); ?>">Home</a></li>
                <li class="breadcrumb-item active">Data Panen</li>
            </ol>
        </div>
    </div>
    <div class="row">
        <!-- Column -->
        <div class="card col-md-12">
            <div class="card-body">
                <?php if(session('success')): ?>
                <div class="card-body">
                    <div class="alert alert-success alert-dismissible show fade">
                        <div class="alert-body">
                            <button class="close" data-dismiss="alert">
                                <span>&times;</span>
                            </button>
                            <?php echo e(session('success')); ?>

                        </div>
                    </div>
                </div>
                <?php elseif(session('warning')): ?>
                <div class="card-body">
                    <div class="alert alert-warning alert-dismissible show fade">
                        <div class="alert-body">
                            <button class="close" data-dismiss="alert">
                                <span>&times;</span>
                            </button>
                            <?php echo e(session('warning')); ?>

                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <h4 class="card-title">Data Panen</h4>
                <?php if(Auth::user()->role == 'Pengepul'): ?>
                <a href="<?php echo e(URL('/panen/create')); ?>" class="btn btn-primary">Tambah Data Panen</a>
                
                <div class="row">
                    <div class="table-responsive m-t-20">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 5%">No.</th>
                                    <th style="width: 25%">Tanggal</th>
                                    <th style="width: 20%">Nama Petani</th>
                                    <th style="width: 15%">Dusun</th>
                                    <th style="width: 15%">Berat</th>
                                    <?php if(Auth::user()->role == 'Pengepul'): ?>
                                    <th style="width: 20%">Penjualan</th>
                                    <?php elseif(Auth::user()->role == 'Kades'): ?>
                                    <th style="width: 20%">Aksi</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataPanen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $panen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($panen->tanggal)->translatedFormat("l, d F Y")); ?></td>
                                    <td><?php echo e($panen->name); ?></td>
                                    <td><?php echo e($panen->dusun); ?></td>
                                    <td><?php echo e($panen->berat); ?> Kg</td>
                                    <?php if($panen->hasil_penjualan == 0 && Auth::user()->role == 'Pengepul'): ?>
                                    <td><a href="<?php echo e(URL('/panen/jual')); ?>" class="btn btn-warning">Masukkan Harga</a></td>
                                    <?php elseif($panen->hasil_penjualan != 0 && Auth::user()->role == 'Pengepul'): ?>
                                    <td>Rp <?php echo e(number_format($panen->hasil_penjualan,2,',','.')); ?></td>
                                    <?php elseif(Auth::user()->role == 'Kades'): ?>
                                    <td><a href="" class="btn btn-success">Detail</a></td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php else: ?>
                <div class="row">
                    <div class="table-responsive m-t-20">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 5%">No.</th>
                                    <th style="width: 45%">Tanggal</th>
                                    <th style="width: 30%">Berat</th>
                                    <th style="width: 20%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataPanen2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $panen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($panen->tanggal)->translatedFormat("l, d F Y")); ?></td>
                                    <td><?php echo e($panen->berat); ?> Kg</td>
                                    <td><a href="" class="btn btn-success">Detail</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coolyeah\laragon\www\joyomulyo\resources\views/panen/index.blade.php ENDPATH**/ ?>